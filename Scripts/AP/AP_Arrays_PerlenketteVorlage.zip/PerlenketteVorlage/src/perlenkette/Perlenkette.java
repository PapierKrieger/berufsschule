package perlenkette;

public class Perlenkette {

	private Kreis[] kette;

	public Perlenkette() {
		this(10, "blau");
	}

	public Perlenkette(int laenge, String farbe) {
		if (laenge < 0) {
			laenge = 1;
		}
		kette = new Kreis[laenge];
		final int radius = 20;
		final int posY = 50;
		for (int i = 0; i < laenge; i++) {
			kette[i] = new Kreis(radius + 2 * i * radius, posY, radius, farbe);

		}
	}
}
